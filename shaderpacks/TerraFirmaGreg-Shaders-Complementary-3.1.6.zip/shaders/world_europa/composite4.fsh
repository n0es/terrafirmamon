#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define COMPOSITE4
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/composite4.glsl"
