

//   ___                _                   _        _   ___      _      _
//  / __|_  _ _ __ _ __| |___ _ __  ___ _ _| |_ __ _| | | _ \__ _| |_ __| |_  ___ ___
//  \__ \ || | '_ \ '_ \ / -_) '  \/ -_) ' \  _/ _` | | |  _/ _` |  _/ _| ' \/ -_|_-<
//  |___/\_,_| .__/ .__/_\___|_|_|_\___|_||_\__\__,_|_| |_| \__,_|\__\__|_||_\___/__/
//           |_|  |_|
// Settings added by Supplemental Patches

#ifndef ENTITY_MATERIALS_SETTINGS_FILE
#define ENTITY_MATERIALS_SETTINGS_FILE

//#define GLOWING_ARMOR_TRIM
//#define SITUATIONAL_GLOWING_TRIMS
#define END_CRYSTAL_EMISSION 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]

#define HOLLER_GLOWING_INTENSITY 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

#define GLOWING_ORETORTOISE_MULT 1.0 //[0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]

#define GLOWING_ORETORTOISE

#define SITUATIONAL_ORETORTOISE

#endif