#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define COMPOSITE6
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/composite6.glsl"
