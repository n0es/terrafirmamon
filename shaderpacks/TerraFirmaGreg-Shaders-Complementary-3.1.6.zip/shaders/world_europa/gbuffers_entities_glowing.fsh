#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_GLOWING
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/gbuffers_entities.glsl"
